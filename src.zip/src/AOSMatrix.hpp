//
// This file is part of the course materials for AMATH483/583 at the University of Washington,
// Spring 2018
//
// Licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License
// https://creativecommons.org/licenses/by-nc-sa/4.0/
//
// Author: Andrew Lumsdaine
//

#ifndef __AOSMATRIX_HPP
#define __AOSMATRIX_HPP

#include <cassert>
#include <vector>
#include <iostream>
#include <fstream>

#include "Vector.hpp"

class AOSMatrix {
public:
    AOSMatrix() {} // default constructor
    AOSMatrix(size_t M, size_t N) {
        /* write me */
    }
    void push_back(size_t i, size_t j, double val) {
        /* write me */
    }

    void clear() {
        /* write me */
    }

    void reserve(size_t n) {
        /* write me */
    }

    size_t num_rows()     const { return 0; } /* fix me */
    size_t num_cols()     const { return 0; } /* fix me */

    size_t num_nonzeros() const { return 0; } /* fix me */

    void readMatrix(std::string file) { // read from file
        /* write me */
    }

    void matvec(const Vector& x, Vector& y) const {
        /* write me */
    }

private:
    class Element {
    public:
        size_t row, col;
        double val;
    };
    size_t num_rows_, num_cols_;
    std::vector<Element> storage_;
};

#endif // __AOSMATRIX_HPP
