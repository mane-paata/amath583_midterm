These files are designed to help you determine whether (1) you've implemented all the necessary functions and (2) your code compiles and runs without any errors. This code is not officially part of the assignment and is being provided as an extra way to check your code only if you wish to use it.

Once you have finished modyfing AOSMatrix.hpp, CSCMatrix.hpp and amath583.cpp, you may test your code as follows:

1. Copy Your Midterm Files into the Directory "CompileTest": 
You should overwrite only* the following files in CompileTest with your implementations

	amath583.cpp
	AOSMatrix.hpp
	CSCMatrix.hpp          (AMATH 583 only)
	
* also include any additional hpp/cpp files that you have either created or modified for your specific implementations (note that you may need to modify the makefile for this to compile).

2. Compile the Code:
Run the command "make all" from within the directory CompileTest. Make sure that your code compiles without errors. Warnings are OK.

3. Run Your Code:
AMATH 483 students should run ./main_AOS.exe
AMATH 583 students should also run ./main_CSC.exe
both should programs should execute without errors 

REMARK: 
This code will not test your implementations to verify if they are correct. Therefore, even if both programs run without errors, it does not mean that you will necessarily receive full credit on the assignment.