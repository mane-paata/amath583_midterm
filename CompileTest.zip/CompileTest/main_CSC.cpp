#include <iostream>
#include "CSCMatrix.hpp"
#include "Vector.hpp"
#include "amath583.hpp"

int main()
{
    CSCMatrix M(0,0);
    
    std::cout << "reading inputCOOMatrix.txt" << std::endl;
    M.readMatrix("inputCOOMatrix.txt");

    std::cout << "\tnum rows: " << M.num_rows() << std::endl;
    std::cout << "\tnum cols: " << M.num_cols() << std::endl;
    std::cout << "\tnum nonzero: " << M.numNonzeros() << std::endl;

    //generate vector and multiply by matrix
    std::size_t n = M.num_cols();
    Vector x(n);
    Vector b(n);
    
    
    for(std::size_t i = 0; i < n; i ++)
    {
        x(i) = 1.0;
    }
    M.matvec(x, b);
    b = M * x;

    // clear matrix and add a single element at 0,0 position
    M.clear();
    M.openForPushBack();
    M.reserve(1);
    M.push_back(0,0,1.0);
    M.closeForPushBack();
}